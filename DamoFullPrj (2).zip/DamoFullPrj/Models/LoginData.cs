﻿namespace DamoFullPrj.Models
{
    public class LoginData
    {
        public string emailLogin { get; set; }
        public string passLogin { get; set; }
    }
}
